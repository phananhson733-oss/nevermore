# ChatGPT Pro review and correction record

Date: 2026-07-31 (Asia/Shanghai)

Conversation:
`https://chatgpt.com/c/6a6b4faf-dfe8-83e8-852c-6747be965e1e`

## First review package

- Baseline: `4860f3e4217255b7e72b0c0d4c2d1ad01edf3121`
- Size: 152692 bytes
- SHA-256:
  `42834ad204419a9668aaaa6efbb577a578316b6f28153dcf345f2f37a737b661`
- Files: 25
- Archive validation by ChatGPT Pro: size, digest, and member count matched.
- Static TypeScript parsing by ChatGPT Pro: zero syntax errors.

## First verdict

ChatGPT Pro returned `FAIL` with three blocking findings:

1. Search and kind filters forced matching branches open while branch and global
   expand/collapse buttons remained enabled. Activating those controls changed
   hidden state but produced no immediate visual response.
2. Every recursive list level added mobile and desktop indentation. A
   constructed 24-level URL path produced internal horizontal overflow and left
   the deepest row almost unreadable on a 390-pixel viewport.
3. The consent route handled returned PostgREST errors but not thrown client or
   query exceptions. It also destructured non-object JSON and assumed every
   category was a non-null object.

The review also identified non-blocking precision issues:

- the `Depth` header represented crawl depth rather than visual tree depth;
- copy for branches outside the main hierarchy incorrectly described all
  descendants as having no inbound links;
- desktop metric headers did not include the row's horizontal padding;
- additional-inbound display depended on aggregate counts whose projected edge
  could be truncated;
- deep paths, forced expansion, and thrown persistence failures lacked focused
  regression coverage.

## Corrections applied by Codex

- Disabled per-branch and global expand/collapse controls whenever a search or
  kind filter temporarily forces ancestors open. Disabled styling and native
  button semantics make the temporary state explicit.
- Capped visual indentation at five levels while preserving the nested list
  semantics. Deeper rows use an `…/segment` visual prefix and retain the full
  path in their accessible name and title.
- Added a 25-node/24-level mobile Playwright fixture. It asserts that the
  deepest selectable row remains at least 160 pixels wide and that neither the
  tree scroller nor the document overflows horizontally.
- Validated the consent JSON object, category entries, visitor ID, and policy
  version before persistence. Client creation, IP hashing, and query execution
  now share a sanitized exception boundary.
- Added route tests for null JSON, null categories, thrown client creation,
  thrown queries, missing configuration, missing table, returned database
  errors, and successful inserts.
- Renamed the column to `Crawl depth` / `抓取深度`, corrected outside-branch
  copy, and aligned desktop headers with row padding.
- Derived the secondary badge only from other edges actually present in the
  bounded public projection. Aggregate inbound totals remain visible in their
  dedicated column.

## Independent Codex verification after corrections

- Marketing unit scope: 4 files, 25 tests passed.
- Marketing typecheck: passed.
- Marketing lint: passed.
- Marketing production build: passed.
- Internal-link Playwright suite: 3 tests passed, including the 24-level
  390-pixel mobile case.

The final corrected package was sent back to the same ChatGPT Pro conversation
for a second review before release.
